from flask import Flask, request, jsonify
from flask_cors import CORS
from supabase import create_client, Client
from dotenv import load_dotenv
import os
from datetime import date, datetime
from flask_socketio import SocketIO, emit

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)
CORS(app)
app.config['SECRET_KEY'] = 'PharmaCheck'
socketio = SocketIO(app, cors_allowed_origins="*")  #alloww frontend connections

# Initialize Supabase client
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

def checkForExpiry(dateString):
    expiry_date = datetime.strptime(dateString, "%Y-%m-%d").date()
    # Get today's date
    today = date.today()
    # Compare and return True if Expiredd, otherwise False
    if today > expiry_date:
        return True
    else:
        return False
    

# Home route
# @app.route('/')
# def home():
#     return render_template('index.html')  # Make sure you create a templates/index.html file

#  Example API route. 
#  Dw abt this. Just used this to access the data directly so i don't have to login to Supabase everytime
@app.route('/api/verify/data', methods=['GET'])
def get_data():
    response1 = supabase.table("AMOXICILLIN_BATCH").select("*").execute() 
    response2 = supabase.table("AMOXICILLIN_SERIAL").select("*").execute()
    return jsonify({"AMOXICILLIN_BATCH":response1.data,"AMOXICILLIN_SERIAL":response2.data})

@app.route('/api/report/data', methods=['GET'])
def get_data_report():
    response1 = supabase.table("report_page").select("*").execute() 
    return jsonify({"Table Data":response1.data})

# Verify serial/batch numbers here
@app.route('/api/verify', methods=['POST'])
def verify_data():
    user_input = request.json.get('serial')
    response1 = supabase.table("AMOXICILLIN_BATCH").select("*").eq("batch_number", user_input).execute() 
    response2 = supabase.table("AMOXICILLIN_SERIAL").select("*").eq("serial_no", user_input).execute()
    
    #Evaluate cases
    if response1.data:
        for record in response1.data:
            if checkForExpiry(record['expiry_date']):
                return jsonify({"status": "EXPIRED",})
            else:
                return jsonify({"status": "AUTHENTIC", "expiryDate": record['expiry_date'], "batch": record['batch_number'], "manufacturer": record['manufacturer']})
            # print(record['expiry_date'])
    
    elif response2.data:
        for record2 in response2.data:
            response3 = supabase.table("AMOXICILLIN_BATCH").select("*").eq("batch_number", record2['batch_number']).execute() 
            if response3.data:
                for record3 in response3.data:
                    # Convert expiry string to a date object
                    if checkForExpiry(record3['expiry_date']):
                        return jsonify({"status": "EXPIRED","expiryDate": record3['expiry_date'], "batch": record3['batch_number'], "manufacturer": record3['manufacturer'], "serial": record2['serial_no']})
                    else:
                        return jsonify({"status": "AUTHENTIC", "expiryDate": record3['expiry_date'], "batch": record3['batch_number'], "manufacturer": record3['manufacturer'], "serial": record2['serial_no']})
            else:
                return jsonify({"status": "COUNTERFEIT"})
    else:
        return jsonify({"status": "COUNTERFEIT"})


@app.route("/api/report", methods=["POST"])
def add_report():
    data = request.get_json()

    # Extract nested form_data
    form = data.get("form_data", {})

    # Required fields
    product_name = form.get("productName")
    batch_serial = form.get("batchSerial")
    location = form.get("location")
    description = form.get("description")

    # Optional fields
    reporter_name = form.get("reporterName")
    reporter_email = form.get("reporterEmail")

    # --- Validate required fields ---
    if not all([product_name, batch_serial, location, description]):
        return jsonify({"error": "Missing required fields"}), 400
    
    # --- Build record dictionary ---
    record = {
        "product_name": product_name,
        "batch_serial": batch_serial,
        "location": location,
        "description": description
    }

    # Add optional fields only if provided
    if reporter_name:
        record["name"] = reporter_name
    if reporter_email:
        record["email"] = reporter_email

    # --- Insert into Supabase ---
    response = supabase.table("report_page").insert(record).execute()

    # ✅ Check status code instead of .error
    if not response:
        return jsonify({
            "error": f"Supabase insert failed (status {response})"
        }), 400
    return jsonify({
        "message": "Report added successfully!",
        "data": response.data
    }), 201

# #Socket io connection signals
# @socketio.on("connect")
# def handle_connect():
#     print("Client connected")

# @socketio.on("disconnect")
# def handle_disconnect():
#     print("Client disconnected")

# Run the app
if __name__ == '__main__':
    socketio.run(app, debug=True, host="0.0.0.0", port=5000)